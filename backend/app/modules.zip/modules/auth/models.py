from __future__ import annotations

from datetime import datetime
from uuid import uuid4

from sqlalchemy import Boolean, DateTime, ForeignKey, String, func
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.db.base import Base


class T_User(Base):
    __tablename__ = "T_User"

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=lambda: str(uuid4()))
    username: Mapped[str] = mapped_column(String(64), unique=True, index=True, nullable=False)
    password_hash: Mapped[str] = mapped_column(String(255), nullable=False)
    is_active: Mapped[bool] = mapped_column(Boolean, nullable=False, default=True)
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        nullable=False,
        server_default=func.now(),
    )
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        nullable=False,
        server_default=func.now(),
        onupdate=func.now(),
    )

    user_roles: Mapped[list["T_UserRole"]] = relationship(
        "T_UserRole",
        back_populates="user",
        cascade="all, delete-orphan",
    )


class T_Role(Base):
    __tablename__ = "T_Role"

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=lambda: str(uuid4()))
    code: Mapped[str] = mapped_column(String(64), unique=True, index=True, nullable=False)
    name: Mapped[str] = mapped_column(String(100), nullable=False)

    user_roles: Mapped[list["T_UserRole"]] = relationship(
        "T_UserRole",
        back_populates="role",
        cascade="all, delete-orphan",
    )


class T_UserRole(Base):
    __tablename__ = "T_UserRole"

    user_id: Mapped[str] = mapped_column(
        String(36),
        ForeignKey("T_User.id"),
        primary_key=True,
    )
    role_id: Mapped[str] = mapped_column(
        String(36),
        ForeignKey("T_Role.id"),
        primary_key=True,
    )

    user: Mapped["T_User"] = relationship("T_User", back_populates="user_roles")
    role: Mapped["T_Role"] = relationship("T_Role", back_populates="user_roles")
