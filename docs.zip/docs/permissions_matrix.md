# Permissions Matrix (Phase 3 API Tasks) — Unified v4

This matrix maps each endpoint to a unified permission code aligned with `docs/02_permissions_rbac.md` naming style.


## Convention
- Read/Create/Edit/Delete/Action/Print/Export/Attach/EditLimited


## Matrix

- `GET /clients` → `Client.Read`  (task: `BE-APIv4-001_clients_get_clients`)
- `POST /clients` → `Client.Create`  (task: `BE-APIv4-002_clients_post_clients`)
- `PUT /clients/{id}` → `Client.Edit`  (task: `BE-APIv4-003_clients_put_clients_id`)
- `PUT /clients/{id}/deactivate` → `Client.Action`  (task: `BE-APIv4-004_clients_put_clients_id_deactivate`)
- `GET /cases` → `Case.Read`  (task: `BE-APIv4-005_cases_get_cases`)
- `POST /cases` → `Case.Create`  (task: `BE-APIv4-006_cases_post_cases`)
- `GET /cases/{case_id}` → `Case.Read`  (task: `BE-APIv4-007_cases_get_cases_case_id`)
- `PUT /cases/{case_id}` → `Case.Edit`  (task: `BE-APIv4-008_cases_put_cases_case_id`)
- `POST /cases/{case_id}/limited-edit` → `Case.EditLimited`  (task: `BE-APIv4-009_cases_post_cases_case_id_limited-edit`)
- `GET /cases/export` → `Case.Export`  (task: `BE-APIv4-010_cases_get_cases_export`)
- `GET /documents` → `Doc.Read`  (task: `BE-APIv4-011_documents_get_documents`)
- `POST /documents` → `Doc.Create`  (task: `BE-APIv4-012_documents_post_documents`)
- `GET /documents/{id}` → `Doc.Read`  (task: `BE-APIv4-013_documents_get_documents_id`)
- `PUT /documents/{id}` → `Doc.Edit`  (task: `BE-APIv4-014_documents_put_documents_id`)
- `POST /documents/{id}/attachments` → `Doc.Attach`  (task: `BE-APIv4-015_documents_post_documents_id_attachments`)
- `GET /documents/{id}/attachments/{att_id}/download` → `Doc.Attach`  (task: `BE-APIv4-016_documents_get_documents_id_attachments_att_id_download`)
- `GET /tasks` → `Task.Read`  (task: `BE-APIv4-017_tasks_get_tasks`)
- `POST /tasks` → `Task.Create`  (task: `BE-APIv4-018_tasks_post_tasks`)
- `GET /tasks/{id}` → `Task.Read`  (task: `BE-APIv4-019_tasks_get_tasks_id`)
- `PUT /tasks/{id}` → `Task.Edit`  (task: `BE-APIv4-020_tasks_put_tasks_id`)
- `POST /tasks/{id}/close` → `Task.Action`  (task: `BE-APIv4-021_tasks_post_tasks_id_close`)
- `POST /tasks/{id}/reopen` → `Task.Action`  (task: `BE-APIv4-022_tasks_post_tasks_id_reopen`)
- `POST /tasks/{id}/cancel` → `Task.Action`  (task: `BE-APIv4-023_tasks_post_tasks_id_cancel`)
- `GET /tasks/today?as=worker|supervisor` → `Task.Read`  (task: `BE-APIv4-024_tasks_get_tasks_today?as=worker|supervisor`)
- `GET /fees/drafts` → `Fee.Draft.Read`  (task: `BE-APIv4-025_fees_get_fees_drafts`)
- `POST /fees/drafts` → `Fee.Draft.Create`  (task: `BE-APIv4-026_fees_post_fees_drafts`)
- `GET /fees/drafts/{id}` → `Fee.Draft.Read`  (task: `BE-APIv4-027_fees_get_fees_drafts_id`)
- `PUT /fees/drafts/{id}` → `Fee.Draft.Edit`  (task: `BE-APIv4-028_fees_put_fees_drafts_id`)
- `POST /fees/drafts/{id}/lock` → `Fee.Draft.Action`  (task: `BE-APIv4-029_fees_post_fees_drafts_id_lock`)
- `POST /fees/drafts/{id}/unlock` → `Fee.Draft.Action`  (task: `BE-APIv4-030_fees_post_fees_drafts_id_unlock`)
- `POST /fees/drafts/{id}/items` → `Fee.Item.Create`  (task: `BE-APIv4-031_fees_post_fees_drafts_id_items`)
- `PUT /fees/items/{item_id}` → `Fee.Item.Edit`  (task: `BE-APIv4-032_fees_put_fees_items_item_id`)
- `DELETE /fees/items/{item_id}` → `Fee.Item.Delete`  (task: `BE-APIv4-033_fees_delete_fees_items_item_id`)
- `GET /fees/rates` → `Fee.Rate.Read`  (task: `BE-APIv4-034_fees_get_fees_rates`)
- `POST /fees/rates` → `Fee.Rate.Create`  (task: `BE-APIv4-035_fees_post_fees_rates`)
- `PUT /fees/rates/{id}` → `Fee.Rate.Edit`  (task: `BE-APIv4-036_fees_put_fees_rates_id`)
- `GET /bills` → `Bill.Read`  (task: `BE-APIv4-037_billing_get_bills`)
- `POST /bills/from-drafts` → `Bill.Create`  (task: `BE-APIv4-038_billing_post_bills_from-drafts`)
- `POST /bills/manual` → `Bill.Create`  (task: `BE-APIv4-039_billing_post_bills_manual`)
- `GET /bills/{id}` → `Bill.Read`  (task: `BE-APIv4-040_billing_get_bills_id`)
- `GET /bills/{id}/print` → `Bill.Print`  (task: `BE-APIv4-041_billing_get_bills_id_print`)
- `GET /payments` → `Payment.Read`  (task: `BE-APIv4-042_billing_get_payments`)
- `POST /payments` → `Payment.Create`  (task: `BE-APIv4-043_billing_post_payments`)
- `GET /payments/{id}` → `Payment.Read`  (task: `BE-APIv4-044_billing_get_payments_id`)
- `POST /offsets` → `Payment.Create`  (task: `BE-APIv4-045_billing_post_offsets`)
- `POST /offsets/{id}/reverse` → `Payment.Create`  (task: `BE-APIv4-046_billing_post_offsets_id_reverse`)
- `GET /cases/{case_id}/receipts` → `CaseReceipt.Read`  (task: `BE-APIv4-047_billing_get_cases_case_id_receipts`)
