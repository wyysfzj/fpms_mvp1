# Backend tasks — execute in order
## Atomic Task Rules (MUST READ)

1. One task = one file = one responsibility.
2. Task scope MUST be deterministic. No conditional language is allowed.
3. Design documents are the single source of truth.
4. Task prompt MUST fully enumerate fields / behavior.
5. If a task conflicts with design docs, follow the design docs.

## Prerequisite (DB)
You MUST apply DB migrations before running backend tasks.

- Reference: `backend/docs/db_migrations_overview.md`

```bash
cd backend
alembic upgrade head
```
